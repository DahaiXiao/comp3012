
import express from "express";
const router = express.Router();
import { ensureAuthenticated } from "../middleware/checkAuth";
import { session } from "passport";

// display admin dashboard
router.get("/", ensureAuthenticated, (req, res) => {
   const sessions: any[]=[
       {sessionId: "123456789"},
 ]
  
  res.render("admin", {
    user: req.user,
    sessions: req.session
  });
});

// revoke session
router.post("/revoke/:sessionId", ensureAuthenticated, (req, res) => {
  const sessionId = req.params.sessionId;
  req.sessionStore.destroy(sessionId);
  res.redirect('/admin');
});


export default router;
