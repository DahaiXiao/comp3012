import express from "express";

const router = express.Router();
import { ensureAuthenticated} from "../middleware/checkAuth";
import { Store } from "express-session";
import { session } from "passport";

router.get("/", (req, res) => {
  //res.send("welcome");
  res.render("login", {message: []})
});

router.get("/dashboard", ensureAuthenticated, (req, res) => {
 

 // console.log(req.user);
 // res.render("dashboard", {
 //  user: req.user,
  //});
  // go to admin dashboard
  if (req.user && req.user.role === "admin") {
   //  res.redirect("/admin");  did not get the session ~___~!
 //const sessions: any[]=[ 
  //{sessionId: "underindexrouter"}];

  if(req.sessionStore.all){
   
  const se:{}[]=[];
  req.sessionStore.all((err, sessions)=>{
   if(sessions){
    const sesids = Object.keys(sessions);

    for(const id of sesids){
      //@ts-ignore
      const session = sessions[id];
      const pss = session.passport.user;
      se.push({sessionId:id, userid:pss});
      
    }
    res.render("admin", {
      user: req.user,
     sessions: se,
    });
  
    }
    });
    
  }
 } else 
 {
  res.render("dashboard", {
    user: req.user,
    
  });
  
  }




});



router.post("/revoke", (req, res) => {

  const se=req.body;
  req.sessionStore.destroy(se.sessionid)
  res.redirect("/admin")
});
export default router;
