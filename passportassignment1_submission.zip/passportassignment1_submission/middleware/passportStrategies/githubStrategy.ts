import passport from "passport";
import { Strategy as GitHubStrategy } from 'passport-github2';
import { PassportStrategy } from '../../interfaces/index';
import { Request, Response, NextFunction } from "express";
import 'dotenv/config'
import { getUserById } from "../../controllers/userController";
import { userModel } from "../../models/userModel";

const githubStrategy: GitHubStrategy = new GitHubStrategy(
    {
        clientID: process.env.clientID!,
        clientSecret: process.env.clientSecret!,
        callbackURL: "http://localhost:8000/auth/github/callback",
        passReqToCallback: true,
        scope: ['user:email'],
     
    },
    
    /* FIX ME 😭---- */
    async function(req: Request, accessToken: string, refreshToken: string, profile: any, done: (err: Object | null, user: false | Express.User | null | undefined) => void) {
        const user = userModel.findOrCreateUser(profile)
        return done(null, user)
    },
);

const passportGitHubStrategy: PassportStrategy = {
    name: 'github',
    strategy: githubStrategy,
};


export default passportGitHubStrategy;

